/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package alisaforanc195wgu;


import java.io.IOException;
import utilities.DataBaseConnection;
import static utilities.DataBaseConnection.conn;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.FileHandler;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.logging.SimpleFormatter;
import javafx.application.Application;
import static javafx.application.Application.launch;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

/**
 *
 * @author amf74
 */
public class AlisaForanC195wgu extends Application {

   

  
    
    @Override
    public void start(Stage stage) throws Exception {
        Parent root = FXMLLoader.load(getClass().getResource("/view/LogInForm.fxml"));
        
        Scene scene = new Scene(root);
        
        stage.setScene(scene);
        stage.show();
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws ClassNotFoundException, SQLException, Exception {
            
        
        
        DataBaseConnection.makeConnection();
        
        Statement stmnt = conn.createStatement();
        
        

            
          
              
        launch(args);
        DataBaseConnection.closeConnection();
        
        
        
        
        
       
  
    }
    
}
        
        
        
        
        
        
        
   
    
