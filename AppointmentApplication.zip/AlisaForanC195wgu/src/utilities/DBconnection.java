/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package utilities;

import static utilities.DataBaseConnection.conn;
import java.sql.SQLException;
import java.sql.Statement;
import static javafx.application.Application.launch;



/**
 *
 * @author amf74
 */
public class DBconnection {
   
     public static void main(String[] args) throws ClassNotFoundException, SQLException, Exception {
            
        
        
        DataBaseConnection.makeConnection();
        
        Statement stmnt = conn.createStatement();
        
        

            
          
              
        launch(args);
        DataBaseConnection.closeConnection();
   }

    
}
