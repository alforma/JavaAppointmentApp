
package utilities;

import com.mysql.jdbc.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;


public class DataBaseConnection {

    private static final String databaseName = "U04sOo";
    private static final String db_URL = "jdbc:mysql://3.227.166.251/" + databaseName;
    private static final String username = "U04sOo";
    private static final String password = "53688334759";
    private static final String driver = "com.mysql.jdbc.Driver";
                                        
   public static Connection conn;
    
    
    public static void makeConnection() throws ClassNotFoundException, SQLException, Exception
            {
            Class.forName("com.mysql.jdbc.Driver");
            conn =  (Connection) DriverManager.getConnection(db_URL,username,password);
            System.out.println("Connection Success");
            
            }
    
        
    public static void closeConnection() throws ClassNotFoundException, SQLException,Exception 
            {
           conn.close();
           System.out.println("Connection closed");
            
            }

   

}
