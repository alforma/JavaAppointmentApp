
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package utilities;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;



/**
 *
 *
 *
 *
 * @author amf74
 */
public class CalendarTime {

    
     private static final String databaseName = "U04sOo";
    private static final String db_URL = "jdbc:mysql://3.227.166.251/" + databaseName;
    private static final String username = "U04sOo";
    private static final String password = "53688334759";
    private static final String driver = "com.mysql.jdbc.Driver";
    
    public static void main(String[] args) {
  //Getting the LocalDateTime Objects from String values
		DateTimeFormatter df = DateTimeFormatter.ofPattern("MMM dd, yyyy hh:mm:ss aa"); 
		String startTimetxt = "";

		LocalDateTime ldtStart = LocalDateTime.parse(startTimetxt, df);


		//Showing how to parse the Date/Time String
		DateTimeFormatter dFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd"); 
		LocalDate localDate = LocalDate.parse(startTimetxt.substring(0, 10), dFormatter);
		System.out.println("The local date is " + localDate);
		
		DateTimeFormatter tFormatter = DateTimeFormatter.ofPattern("kk:mm:ss.S"); 
		LocalTime localTime = LocalTime.parse(startTimetxt.substring(11), tFormatter);
		System.out.println("The local time is " + localTime);
		
		//Getting the day of the week
		System.out.println(ldtStart.getDayOfWeek());
		
		//Convert to a ZonedDate Time in UTC
		ZoneId zid = ZoneId.systemDefault();

		ZonedDateTime zdtStart = ldtStart.atZone(zid);
		System.out.println("Local Time: " + zdtStart);
		ZonedDateTime utcStart = zdtStart.withZoneSameInstant(ZoneId.of("UTC"));
		System.out.println("Zoned time: " + utcStart);
		ldtStart = utcStart.toLocalDateTime();
		System.out.println("Zoned time with zone stripped:" + ldtStart);
		//Create Timestamp values from Instants to update database
		Timestamp startsqlts = Timestamp.valueOf(ldtStart); //this value can be inserted into database
		System.out.println("Timestamp to be inserted: " +startsqlts);

		//insertDB(startsqlts);

		ResultSet rs = null;
		try {
			Connection c = connectDB();
			Statement stmt = c.createStatement();
			String sql;
			sql = "SELECT start FROM appointment where appointmentid = 46";
			rs = stmt.executeQuery(sql);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		//to retrieve from database

		try {
			while(rs.next()) {
				Timestamp tsStart = rs.getTimestamp("start");

				ZoneId newzid = ZoneId.systemDefault();

				ZonedDateTime newzdtStart = tsStart.toLocalDateTime().atZone(ZoneId.of("UTC"));

				ZonedDateTime newLocalStart = newzdtStart.withZoneSameInstant(newzid);
				
				System.out.println("From db in UTC: " + newzdtStart);
				System.out.println("From db in local time: " + newLocalStart);

			}
		} catch (SQLException e) {
			System.err.println(e);
		}


	
    }
	private static Connection connectDB() {
		Connection conn = null;
		try {
			Class.forName("com.mysql.jdbc.Driver");
			conn =  (com.mysql.jdbc.Connection) DriverManager.getConnection(db_URL,username,password);
                        
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();

		}

		return conn;
	}

	private static void insertDB(Timestamp t) {
		try {
			Connection c = connectDB();
			String query = "INSERT INTO appointment VALUES (46,?,?,?,?,?,?,?,?,?,?,?,?)";
			PreparedStatement sql = c.prepareStatement(query);
			sql.setInt(1, 12);
			sql.setString(2, "");
			sql.setString(3, "");
			sql.setString(4, "");
			sql.setString(5, "");
			sql.setString(6, "");
			sql.setTimestamp(7, t);
			sql.setTimestamp(8, t);
			sql.setTimestamp(9, t);
			sql.setString(10, "");
			sql.setTimestamp(11, t);
			sql.setString(12, "");
			sql.execute();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
        
        

}
