/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import java.io.IOException;
import java.net.URL;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.stage.Stage;
import static utilities.DataBaseConnection.conn;

/**
 * FXML Controller class
 *
 * @author amf74
 */
public class RequiredReportsController implements Initializable {

    Stage stage;
    Parent scene;



    @FXML
    private TextArea space1;

    @FXML
    private TextArea space2;

    @FXML
    private TextArea space3;

    @FXML
    void onActionBackToMainScreen(ActionEvent event) throws IOException {
        stage = (Stage) ((Button) event.getSource()).getScene().getWindow();
        scene = FXMLLoader.load(getClass().getResource("/view/MainCustomerSummary.fxml"));
        stage.setScene(new Scene((Parent) scene));
        stage.show();
    }

   



    public void appointmentByMonthRequired() throws SQLException {

        String query = "SELECT type, monthname(start) as 'Month OF Appointment', count(*) as 'TOTAL'\n"
                + " FROM appointment\n"
                + " GROUP BY type, month(start)\n";
//            
        PreparedStatement stmt = conn.prepareStatement(query);
        ResultSet rs = stmt.executeQuery(query);

        StringBuffer organize = new StringBuffer();
        organize.append("Appointment Type                Month Of Appointment                   TOTAL\n");
       organize.append("xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx\n");

        while (rs.next()) {

          organize.append(String.format("%s%s%d\n", String.format("%0$-32s", rs.getString("type")),
                    String.format("%0$-48s", rs.getString("Month OF Appointment")), rs.getInt("TOTAL")));

        }

        stmt.close();

       space1.setText(organize.toString());

    }

    public void consultantScheduleRequired() throws SQLException {
        String query = "SELECT  a.lastUpdateBy,  c.customerName,start, end\n"
                + "FROM U04sOo.appointment a \n"
                + "JOIN U04sOo.customer c on c.customerId = a.customerID\n"
                + "GROUP BY a.lastUpdateBy, month(start),start\n";

        PreparedStatement stmt = conn.prepareStatement(query);
        ResultSet rs = stmt.executeQuery(query);

        StringBuffer organize = new StringBuffer();
        organize.append("Consultant                          Customer           Start                                        End\n");
        organize.append("xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx\n");

        while (rs.next()) {

           organize.append(String.format("%s%s%s%s\n", String.format("%0$-28s", rs.getString("lastUpdateBy")),
                   
                    String.format("%0$-18s", rs.getString("customerName")),
                   String.format("%0$-70s",rs.getString("start")), rs.getString("end")));

        }

        stmt.close();

        space2.setText(organize.toString());

    }

    public void customerNameAndNumber() throws SQLException {
        String query = "SELECT customer.customerName, address.phone\n"
                + "FROM customer, address\n"
               + "GROUP BY customerName";

        PreparedStatement stmt = conn.prepareStatement(query);
        ResultSet rs = stmt.executeQuery(query);

        StringBuffer organize = new StringBuffer();
        organize.append("Customer Name                                         Phone Number\n");
       organize.append("xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx\n");

        while (rs.next()) {

            organize.append(String.format("%s%s\n", String.format("%0$-36s", rs.getString("customerName")), rs.getString("phone")));

        }

        stmt.close();

       space3.setText(organize.toString());

    }

    /**
     * Initializes the controller class.
     *
     * @param url
     * @param rb
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {

        try {
            // TODO

            appointmentByMonthRequired();
        } catch (SQLException ex) {
            Logger.getLogger(RequiredReportsController.class.getName()).log(Level.SEVERE, null, ex);
        }
        try {
            consultantScheduleRequired();
        } catch (SQLException ex) {
            Logger.getLogger(RequiredReportsController.class.getName()).log(Level.SEVERE, null, ex);
        }
        try {
            customerNameAndNumber();
        } catch (SQLException ex) {
            Logger.getLogger(RequiredReportsController.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

}
