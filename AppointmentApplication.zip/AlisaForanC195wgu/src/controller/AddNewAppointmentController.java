/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import DAO.AppointmentDAO;
import DAO.CustomerDAO;
import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.time.LocalDate;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.DatePicker;
import javafx.stage.Stage;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import model.Appointment;
import model.Customer;

import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.scene.control.Alert;

public class AddNewAppointmentController implements Initializable {

    Stage staage;
    Parent root;

    @FXML
    private ComboBox<Customer> customertxt;

    @FXML
    private DatePicker datetxt;

    @FXML
    private ComboBox<Integer> startHour;

    @FXML
    private ComboBox<Integer> startMinute;

    @FXML
    private ComboBox<Integer> endHour;

    @FXML
    private ComboBox<Integer> endMinute;

    @FXML
    private ComboBox<String> typetxt;

    private Stage stage;
    private Object scene;

    boolean validateApt;
    boolean monthlyApt;
    boolean weeklyApt;

    //DATE AND TIME OBJECTS, LISTS
    ObservableList<Integer> starthours = FXCollections.observableArrayList();
    ObservableList<Integer> startminutes = FXCollections.observableArrayList();
    ObservableList<String> typeOfApt = FXCollections.observableArrayList();
    ObservableList<Integer> endhours = FXCollections.observableArrayList();
    ObservableList<Integer> endminutes = FXCollections.observableArrayList();

    ObservableList<Appointment> allAppointments = FXCollections.observableArrayList();

    private ObservableList<Customer> customerCombo;
    ObservableList<Appointment> remind15;

    //DATE FORMATTING FOR THE DATEPICKER AND COMBO BOXES    
    private final DateTimeFormatter dtformatDATE = DateTimeFormatter.ofPattern("yyyy-MM-dd");

    private final DateTimeFormatter dtformatTIME = DateTimeFormatter.ofPattern("HH:mm");

    @FXML
    void onActionSave(ActionEvent event) throws IOException, SQLException, ClassNotFoundException {

        try {
            String errorMessage = "";
            //SAVES INFORMATION TO THE CALENDAR PAGE
            Customer customer = customertxt.getSelectionModel().getSelectedItem();

            int starthour = startHour.getValue();
            int startminute = startMinute.getValue();
            int endhour = endHour.getValue();
            int endminute = endMinute.getValue();
            String type = typetxt.getSelectionModel().getSelectedItem();

            //set and get values for time 
            LocalDate date = datetxt.getValue();
            LocalTime startApt = LocalTime.of(starthour, startminute);
            LocalTime endApt = LocalTime.of(endhour, endminute);
            LocalDateTime startAptDate = LocalDateTime.of(date, startApt);
            LocalDateTime endAptDate = LocalDateTime.of(date, endApt);

            if (checkForOverlaps(startAptDate, endAptDate)) {
                   Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.initOwner(stage);
            alert.setTitle("Overlap alert");
            alert.setHeaderText("Please choose another time");

            alert.showAndWait();
                return;

            }

         

            ////////////////contruct new appointment here  ////////////////////////////////
            Appointment saveApt = new Appointment(customer.getCustomerId(), customer.getCustomerName(), LogInFormController.loggedUser.getUserId(), type, startAptDate, endAptDate);

            AppointmentDAO.addTheApt(saveApt);

            //SENDING THE DATA BACK TO THE CALENDAR FXML  
            stage = (Stage) ((Button) event.getSource()).getScene().getWindow();
            scene = FXMLLoader.load(getClass().getResource("/view/Calendar.fxml"));
            stage.setScene(new Scene((Parent) scene));
            stage.show();

        } catch (NullPointerException e) {
            // Show the error message.
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.initOwner(stage);
            alert.setTitle("Invalid Fields");
            alert.setHeaderText("Please fill in missing fields");

            alert.showAndWait();

        }

    }



    private boolean checkForOverlaps(LocalDateTime startAptDate, LocalDateTime endAptDate) throws ClassNotFoundException, SQLException {

        ObservableList<Appointment> allAppointments = AppointmentDAO.getAppointments();

        for (Appointment a : allAppointments) {

            LocalDateTime start = a.getStart();
            LocalDateTime end = a.getEnd();

            if (startAptDate.getYear() != start.getYear()) {
                continue;
            }
            if (startAptDate.getMonth() != start.getMonth()) {
                continue;
            }
            if (startAptDate.getDayOfMonth() != start.getDayOfMonth()) {
                continue;
            }

            if ((startAptDate.isAfter(start) || startAptDate.isEqual(start)) && startAptDate.isBefore(end)) {
                return true;
            }

            if (endAptDate.isAfter(start) && (endAptDate.isBefore(end) || endAptDate.isEqual(end))) {
                return true;
            }

            if ((startAptDate.isBefore(start) || startAptDate.isEqual(start)) && (endAptDate.isAfter(end) || endAptDate.isEqual(end))) {
                return true;

            }

        }

        return false;
    }

    @FXML
    void onActionBackTOMainPage(ActionEvent event) throws IOException {

        stage = (Stage) ((Button) event.getSource()).getScene().getWindow();
        scene = FXMLLoader.load(getClass().getResource("/view/MainCustomerSummary.fxml"));
        stage.setScene(new Scene((Parent) scene));
        stage.show();

    }

    @FXML
    void onActionCalendarSummary(ActionEvent event) throws IOException {
        stage = (Stage) ((Button) event.getSource()).getScene().getWindow();
        scene = FXMLLoader.load(getClass().getResource("/view/Calendar.fxml"));
        stage.setScene(new Scene((Parent) scene));
        stage.show();
    }

    /**
     *
     *
     * @param url
     * @param rb
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        //SETS COMBO BOXES
        starthours.addAll(8, 9, 10, 11, 12, 13, 14, 15, 16, 17);
        startminutes.addAll(0, 15, 30, 45);

        endhours.addAll(8, 9, 10, 11, 12, 13, 14, 15, 16, 17);
        endminutes.addAll(0, 15, 30, 45);

        typeOfApt.addAll("Presentation", "Introduction", "Follow-up");
        startHour.setItems(starthours);
        startMinute.setItems(startminutes);
        typetxt.setItems(typeOfApt);
        endHour.setItems(endhours);
        endMinute.setItems(endminutes);

        try {
            customerCombo = CustomerDAO.getAllCustomers();
        } catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(AddNewCustomerController.class.getName()).log(Level.SEVERE, null, ex);
        }
        customertxt.setItems(customerCombo);
        customertxt.getSelectionModel();

    }

}
