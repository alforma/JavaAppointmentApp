/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;


import DAO.AppointmentDAO;
import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import model.Appointment;
import model.Customer;


/**
 * FXML Controller class
 *
 * @author amf74
 */
public class  CalendarController  implements Initializable {

    private Stage stage;
    private Object scene;
    Customer custSelected;

    Appointment selected;
    ObservableList<Appointment> aptsArrayList=  AppointmentDAO.getAppointments();
    ObservableList<Appointment> AppointmentsAll = FXCollections.observableArrayList();
    ObservableList<Appointment> AppointmentsWeek = FXCollections.observableArrayList();
    ObservableList<Appointment> AppointmentsMonth = FXCollections.observableArrayList();

    ObservableList<Customer> Customers = FXCollections.observableArrayList();

    private final DateTimeFormatter DTFweekMonth = DateTimeFormatter.ofPattern("yyyy-MM-dd");

  public CalendarController() throws ClassNotFoundException, SQLException {
        this.aptsArrayList = AppointmentDAO.getAppointments();
    }


    @FXML
    private TableView<Appointment> calendarSummaryTable;

    @FXML
    private TableColumn<Appointment, String> customerName;

    @FXML
    private TableColumn<Appointment, LocalDateTime> start;

    @FXML
    private TableColumn<Appointment, LocalDateTime> end;

    @FXML
    private TableColumn<Appointment, String> type;



 
    @FXML
    void weekButtonHandler(ActionEvent event) throws ClassNotFoundException, SQLException {

       // lambda expressions, we can achieve higher efficiency (parallel execution)
          LocalDateTime now = LocalDateTime.now();
        LocalDateTime nowPlus7 = now.plusDays(7);
        FilteredList<Appointment> filteredData = new FilteredList<>(aptsArrayList);
        filteredData.setPredicate(row -> {

            LocalDateTime rowDate = row.getStart();

            return rowDate.isAfter(now) && rowDate.isBefore(nowPlus7);
        });
       calendarSummaryTable.setItems(filteredData);
    }

    @FXML
    void  monthButtonHandler (ActionEvent event) throws ClassNotFoundException, SQLException {
// lambda expressions, we can achieve higher efficiency (parallel execution)
        LocalDateTime now = LocalDateTime.now();
        LocalDateTime nowPlusMonth = now.plusMonths(1);
        FilteredList<Appointment> filteredData = new FilteredList<>(aptsArrayList);
        filteredData.setPredicate(row -> {

            LocalDateTime rowDate = row.getStart();

            return rowDate.isAfter(now) && rowDate.isBefore(nowPlusMonth);
        });
        calendarSummaryTable.setItems(filteredData);
    }

    @FXML
    void allButtonHandler(ActionEvent event) throws ClassNotFoundException, SQLException {
          customerName.setCellValueFactory(appointment -> new SimpleStringProperty(appointment.getValue().getCustomerName()));
            type.setCellValueFactory(appointment -> new SimpleStringProperty(appointment.getValue().getType()));
            end.setCellValueFactory(new PropertyValueFactory<>("end"));
            start.setCellValueFactory(new PropertyValueFactory<>("start"));

          
            AppointmentsAll.addAll(AppointmentDAO.getAppointments());

            calendarSummaryTable.setItems(AppointmentsAll);

    }

    @FXML
    void onActionAddApt(ActionEvent event) throws IOException {
        FXMLLoader loader = new FXMLLoader();
        loader.setLocation(getClass().getResource("/view/AddNewAppointment.fxml"));

        Parent modAptParent = loader.load();
        Scene modAptScene = new Scene(modAptParent);

        AddNewAppointmentController controller = loader.getController();

        Stage stage;
        stage = (Stage) ((Node) event.getTarget()).getScene().getWindow();
        
        stage.setScene(modAptScene);
        stage.show();
    }

    @FXML
    void onActionBackToMainScreen(ActionEvent event) throws IOException {
        stage = (Stage) ((Button) event.getSource()).getScene().getWindow();
        scene = FXMLLoader.load(getClass().getResource("/view/MainCustomerSummary.fxml"));
        stage.setScene(new Scene((Parent) scene));
        stage.show();

    }

    @FXML
    void onActionDeleteApt(ActionEvent event) throws ClassNotFoundException, SQLException{
  

          Appointment appDelete = calendarSummaryTable.getSelectionModel().getSelectedItem();
     
       calendarSummaryTable.getItems().remove(calendarSummaryTable.getSelectionModel().getSelectedItem());
      AppointmentDAO.deleteAppointment(appDelete);
      
      
          
    }

    

    @FXML
    void onActionModApt(ActionEvent event) throws IOException {

        FXMLLoader loader = new FXMLLoader();
        loader.setLocation(getClass().getResource("/view/ModifyAppointment.fxml"));

        Parent modAptParent = loader.load();
        Scene modAptScene = new Scene(modAptParent);

        Appointment modifiedAppointment = calendarSummaryTable.getSelectionModel().getSelectedItem();

        ModifyAppointmentController controller = loader.getController();

        //
        controller.setModApt(modifiedAppointment);
//
        Stage stage;
        stage = (Stage) ((Node) event.getTarget()).getScene().getWindow();
        stage.setScene(modAptScene);
        stage.show();

    }

    /*
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {

        try {
            customerName.setCellValueFactory(appointment -> new SimpleStringProperty(appointment.getValue().getCustomerName()));
            type.setCellValueFactory(appointment -> new SimpleStringProperty(appointment.getValue().getType()));
            end.setCellValueFactory(new PropertyValueFactory<>("end"));
            start.setCellValueFactory(new PropertyValueFactory<>("start"));

         
            AppointmentsAll.addAll(AppointmentDAO.getAppointments());

            calendarSummaryTable.setItems(AppointmentsAll);

      
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(CalendarController.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(CalendarController.class.getName()).log(Level.SEVERE, null, ex);

        }

    }
}
