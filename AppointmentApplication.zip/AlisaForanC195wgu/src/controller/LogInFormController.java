/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import DAO.AppointmentDAO;
import DAO.UserDAO;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.net.URL;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Locale;
import java.util.ResourceBundle;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import model.Appointment;
import model.User;

/**
 * FXML Controller class
 *
 * @author amf74
 */
public class LogInFormController implements Initializable {

    static Stage stage;

    ResourceBundle rb;
    Locale userLocale;

    Parent root;

    @FXML
    private Label userNameLabel;

    @FXML
    private Label passWord;

    @FXML
    private TextField userNameTxt;

    @FXML
    private TextField passWordTxt;

    @FXML
    private Button buttonSubmit;

    private Object scene;

    /////////////////////OBJECTS////////////////////////////////////////
    String translateTitle;
    String translateHeaderText;
    String translateContextText;
    String setTitle;
    String setContent;

    ObservableList<Appointment> remind15;

    public static User loggedUser = null;

    private final DateTimeFormatter logInDTF = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss(z)");

    ////////////////////////////////////////////////////////
    public void startTheApp(Stage stage) {

        this.stage = stage;
        Locale.setDefault(new Locale("es", "ES"));
        ResourceBundle rb = ResourceBundle.getBundle("controller/Language");
        if (Locale.getDefault().getLanguage().equals("es") || Locale.getDefault().getLanguage().equals("en")) {
            System.out.println(rb.getString("translateTitle"));
        }

        Parent main = null;
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("MainCustomerSummaryController.fxml"));
            loader.setResources(rb);
            main = loader.load();

            Scene scene = new Scene(main);

            stage.setScene(scene);

            stage.show();
        } catch (IOException ex) {
            ex.printStackTrace();
        }

    }

    @FXML
    void onActionSubmit(ActionEvent event) throws IOException, SQLException, ClassNotFoundException {

        String username = userNameTxt.getText();
        String password = passWordTxt.getText();

        String errorMessage = "";

        boolean validateUser = true;

        loggedUser = UserDAO.getValidUser(username, password);

        if (loggedUser != null) {
            Alert alert = new Alert(AlertType.INFORMATION);
            alert.setContentText(translateContextText);
            alert.setHeaderText(null);
            alert.showAndWait();

            //returns to main page
            stage = (Stage) ((Button) event.getSource()).getScene().getWindow();
            scene = FXMLLoader.load(getClass().getResource("/view/MainCustomerSummary.fxml"));
            stage.setScene(new Scene((Parent) scene));
            stage.show();

            fifteenMinReminder(loggedUser);

        } else {

            Alert alert = new Alert(AlertType.WARNING);
            alert.setTitle(translateTitle);
            alert.setHeaderText(translateHeaderText);

            alert.showAndWait();

        }
        String FILENAME = "log.txt";
        try (FileWriter fw = new FileWriter(FILENAME, true);
                BufferedWriter bw = new BufferedWriter(fw);
                PrintWriter pw = new PrintWriter(bw)) {
            pw.println(ZonedDateTime.now() + " " + username);
        } catch (IOException e) {
            System.out.println("Logger Error: " + e.getMessage());
        }

    }

    private void fifteenMinReminder(User loggedInUser) throws ClassNotFoundException, SQLException {

        LocalDateTime now = LocalDateTime.now();
        LocalDateTime nowfifteen = now.plusMinutes(15);

        ObservableList<Appointment> allAppointments = AppointmentDAO.getAppointments();

        for (Appointment a : allAppointments) {
            if (loggedInUser.getUserId() != a.getUserId()) {
                continue;
            }
            //  if(startAptDate.isAfter(now.minusMinutes(1)) && startAptDate.isBefore(nowfifteen)){
            LocalDateTime start = a.getStart();
            if (now.getYear() != start.getYear()) {
                continue;
            }
            if (now.getMonth() != start.getMonth()) {
                continue;
            }
            if (now.getDayOfMonth() != start.getDayOfMonth()) {
                continue;
            }

            if (start.isAfter(now) && start.isBefore(nowfifteen)) {
          
                Alert alert = new Alert(AlertType.INFORMATION);
                alert.setTitle(setTitle);
                alert.setHeaderText(null);
                alert.setContentText(setContent);

                alert.showAndWait();
                
                 System.out.println("15 min alert");
                return;
            }

        }

    }

    public static Stage getStage() {
        return stage;
    }

    @Override
    public void initialize(URL url, ResourceBundle rb) {

        this.rb = rb;
        System.out.println(Locale.getDefault());
        Locale locale = Locale.getDefault();
        rb = ResourceBundle.getBundle("controller/Language", locale);
        userNameLabel.setText(rb.getString("USERNAME"));
        passWord.setText(rb.getString("PASSWORD"));
        buttonSubmit.setText(rb.getString("submit"));
        translateTitle = rb.getString("translateTitle");
        translateHeaderText = rb.getString("translateHeaderText");
        translateContextText = rb.getString("translateContextText");
        setTitle = rb.getString("setTitle");
        setContent = rb.getString("setContent");
    }

}
