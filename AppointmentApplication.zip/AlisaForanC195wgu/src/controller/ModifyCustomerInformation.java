/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import DAO.AddressDAO;
import DAO.CityDAO;
import DAO.CountryDAO;
import DAO.CustomerDAO;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import model.Address;
import model.City;
import model.Country;
import model.Customer;

/**
 * FXML Controller class
 *
 * @author amf74
 */
public class ModifyCustomerInformation implements Initializable {

    Stage stage;
    Parent scene;
    Customer customer;

    @FXML
    private TextField customerNametxt;

    @FXML
    private TextField addresstxt;

    @FXML
    private ComboBox<City> citytxt;

    @FXML
    private TextField zipcodetxt;

    @FXML
    private TextField phoneNumbertxt;

    private Customer modCustomer;
    // private Address modAddress;

    boolean validateCustomer;

    private ObservableList<City> cityCombo;

    @FXML
    void onActionCancel(ActionEvent event) throws IOException {
        Alert cancelAlert = new Alert(Alert.AlertType.CONFIRMATION);
        cancelAlert.setTitle("Cancel Confirmation");
        cancelAlert.setHeaderText("Are you sure you would like to cancel?");
       
        cancelAlert.showAndWait();

        //goes back to MainScreen
        stage = (Stage) ((Button) event.getSource()).getScene().getWindow();
        scene = FXMLLoader.load(getClass().getResource("/view/MainCustomerSummary.fxml"));
        stage.setScene(new Scene((Parent) scene));
        stage.show();
    }

    @FXML
    void onActionSave(ActionEvent event) throws IOException, NumberFormatException, NullPointerException {

        if (validateCustomer()) {
            try {

                String customerName = customerNametxt.getText();
                String address = addresstxt.getText();
                City city = citytxt.getSelectionModel().getSelectedItem();
                String postalCode = zipcodetxt.getText();
                String phone = phoneNumbertxt.getText();

                modCustomer.setCustomerName(customerName);
                modCustomer.setAddress(address);
                modCustomer.setPostalCode(postalCode);
                modCustomer.setPhone(phone);

                Address modAddress = new Address(modCustomer.getAddressId(), address, city.getCityId(), postalCode, phone);
                AddressDAO.updateAddress(modAddress);

                CustomerDAO.updateCustomer(modCustomer);

                FXMLLoader loader = new FXMLLoader();
                loader.setLocation(getClass().getResource("/view/MainCustomerSummary.fxml"));
                loader.load();

                MainCustomerSummaryController controller = loader.getController();

                stage = (Stage) ((Button) event.getSource()).getScene().getWindow();
                scene = FXMLLoader.load(getClass().getResource("/view/MainCustomerSummary.fxml"));
                stage.setScene(new Scene(scene));
                stage.show();
            } catch (NumberFormatException e) {
                System.out.println("Please enter valid values in text fields");
            }
        }
    }

    //MAKING SURE ALL TEXT FIELDS ARE FILLED
    private boolean validateCustomer() {
        String customerName = customerNametxt.getText();

        String address = addresstxt.getText();

        City city = citytxt.getValue();

        String postalCode = zipcodetxt.getText();
        String phone = phoneNumbertxt.getText();

        String errorMessage = "";
      
        if (customerName == null || customerName.length() == 0) {
            errorMessage += "Please enter the Customer's name.\n";
        }
        if (address == null || address.length() == 0) {
            errorMessage += "Please enter an address.\n";
        }
        if (city == null) {
            errorMessage += "Please Select a City.\n";
        }

        if (postalCode == null || postalCode.length() == 0) {
            errorMessage += "Please enter the Postal Code.\n";
        } else if (postalCode.length() > 10 || postalCode.length() < 5) {
            errorMessage += "Please enter a valid Postal Code.\n";
        }
        if (phone == null || phone.length() == 0) {
            errorMessage += "Please enter a Phone Number (including Area Code).";
        } else if (phone.length() < 8 || phone.length() > 8) {
            errorMessage += "Please enter a valid phone number in the form of XXX-XXXX\n";
        }
        if (errorMessage.length() == 0) {
            return true;
        } else {
            // Show the error message.
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.initOwner(stage);
            alert.setTitle("Invalid Fields");
            alert.setHeaderText("Please correct invalid Customer fields");
            alert.setContentText(errorMessage);

            alert.showAndWait();

            return false;
        }
    }

    public void setModCustomer(Customer modifiedCustomer) throws IOException {

        this.modCustomer = modifiedCustomer;

        customerNametxt.setText(modifiedCustomer.getCustomerName());
        addresstxt.setText(modifiedCustomer.getAddress());
        zipcodetxt.setText(modifiedCustomer.getPostalCode());
        phoneNumbertxt.setText(modifiedCustomer.getPhone());

        //find the city
        for (City city : cityCombo) {
            if (city.getCityId() == modCustomer.getCityId()) {
                citytxt.getSelectionModel().select(city);
                break;
            }
        }

    }

    /**
     * Initializes the controller class.
     *
     * @param url
     * @param rb
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {

        try {
            cityCombo = CityDAO.getAllCities();
        } catch (Exception ex) {
            Logger.getLogger(AddNewCustomerController.class.getName()).log(Level.SEVERE, null, ex);
        }
        citytxt.setItems(cityCombo);
        citytxt.getSelectionModel().selectFirst();

    }

}
