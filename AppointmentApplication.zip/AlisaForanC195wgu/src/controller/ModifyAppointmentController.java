/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import DAO.AppointmentDAO;
import DAO.CustomerDAO;
import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.stage.Stage;
import model.Appointment;
import model.Customer;

public class ModifyAppointmentController implements Initializable {

    @FXML
    private ComboBox<Customer> customertxt;

    @FXML
    private DatePicker datetxt;

    @FXML
    private ComboBox<String> typetxt;

    @FXML
    private ComboBox<Integer> startHour;

    @FXML
    private ComboBox<Integer> startMinute;

    @FXML
    private ComboBox<Integer> endHour;

    @FXML
    private ComboBox<Integer> endMinute;

    Stage stage;
    Object scene;
    Appointment modAppointment;

    //DATE AND TIME OBJECTS, LISTS
    ObservableList<Integer> starthours = FXCollections.observableArrayList();
    ObservableList<Integer> startminutes = FXCollections.observableArrayList();
    ObservableList<String> typeOfApt = FXCollections.observableArrayList();
    ObservableList<Integer> endhours = FXCollections.observableArrayList();
    ObservableList<Integer> endminutes = FXCollections.observableArrayList();

    private ObservableList<Customer> customerCombo;
    
    
        ObservableList<Appointment> allAppointments = FXCollections.observableArrayList();


    //DATE FORMATTING FOR THE DATEPICKER AND COMBO BOXES    
    private final DateTimeFormatter dtformatDATEM = DateTimeFormatter.ofPattern("yyyy-MM-dd");

    private final DateTimeFormatter dtformatTIMEM = DateTimeFormatter.ofPattern("HH:mm");

    //  private final DateTimeFormatter formatDTimeM = DateTimeFormatter.ISO_LOCAL_DATE_TIME;
    @FXML
    void onActionBackToMainPage(ActionEvent event) throws IOException {
        stage = (Stage) ((Button) event.getSource()).getScene().getWindow();
        scene = FXMLLoader.load(getClass().getResource("/view/MainCustomerSummary.fxml"));
        stage.setScene(new Scene((Parent) scene));
        stage.show();
    }

    @FXML
    void onActionCalendarSummary(ActionEvent event) throws IOException {

        Alert cancelAlert = new Alert(Alert.AlertType.CONFIRMATION);
        cancelAlert.setTitle("Cancel Confirmation");
        cancelAlert.setHeaderText("Are you sure you would like to cancel?");
              cancelAlert.showAndWait();

        //goes back to MainScreen
        stage = (Stage) ((Button) event.getSource()).getScene().getWindow();

        scene = FXMLLoader.load(getClass().getResource("/view/Calendar.fxml"));
        stage.setScene(new Scene((Parent) scene));
        stage.show();

    }

    @FXML
    void onActionSave(ActionEvent event) throws SQLException, IOException, ClassNotFoundException {
try{
        //get form values
        Customer customer = customertxt.getValue();

        int starthour = startHour.getValue();
        int startminute = startMinute.getValue();
        int endhour = endHour.getValue();
        int endminute = endMinute.getValue();
        String typeOfApt = typetxt.getValue();

        //set and get values for time 
        LocalDate date = datetxt.getValue();

        LocalTime startApt = LocalTime.of(starthour, startminute);

        LocalTime endApt = LocalTime.of(endhour, endminute);

        LocalDateTime startAptDate = LocalDateTime.of(date, startApt);
        LocalDateTime endAptDate = LocalDateTime.of(date, endApt);
        
        
        
        
          if (checkForOverlaps(startAptDate, endAptDate)) {
                  Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.initOwner(stage);
            alert.setTitle("Appointment Overlap Alert");
            alert.setHeaderText("Please change times");

            alert.showAndWait();
                return;

            }
            
         

        //set form values
        //contstructor
        modAppointment.setCustomerName(customer.getCustomerName());
        modAppointment.setCustomerId(customer.getCustomerId());
        modAppointment.setStart(startAptDate);
        modAppointment.setEnd(endAptDate);
        modAppointment.setType(typeOfApt);

        AppointmentDAO.updateAPT(modAppointment);
  
        
          stage = (Stage) ((Button) event.getSource()).getScene().getWindow();
        scene = FXMLLoader.load(getClass().getResource("/view/Calendar.fxml"));
        stage.setScene(
          new Scene((Parent) scene));
        stage.show();


   }
        catch(NullPointerException e){
		  // Show the error message.
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.initOwner(stage);
            alert.setTitle("Invalid Fields");
            alert.setHeaderText("Please fill in missing fields");
    

            alert.showAndWait();

	}
    }


        
  


   
    private boolean checkForOverlaps(LocalDateTime startAptDate, LocalDateTime endAptDate) throws ClassNotFoundException, SQLException {

        ObservableList<Appointment> allAppointments = AppointmentDAO.getAppointments();

        for (Appointment a : allAppointments) {

            LocalDateTime start = a.getStart();
            LocalDateTime end = a.getEnd();

            if (startAptDate.getYear() != start.getYear()) {
                continue;
            }
            if (startAptDate.getMonth() != start.getMonth()) {
                continue;
            }
            if (startAptDate.getDayOfMonth() != start.getDayOfMonth()) {
                continue;
            }

            if ((startAptDate.isAfter(start) || startAptDate.isEqual(start)) && startAptDate.isBefore(end)) {
                return true;
            }
           
            if (endAptDate.isAfter(start) && (endAptDate.isBefore(end) || endAptDate.isEqual(end))) {
                return true;
            }

            if ((startAptDate.isBefore(start) || startAptDate.isEqual(start)) && (endAptDate.isAfter(end) || endAptDate.isEqual(end))) {
                return true;
            }
        }

        return false;
    }

    
    
    
    
    
    
    
    
    
    
    
    
    

   

    void setModApt(Appointment modifiedAppointment) throws IOException {

        this.modAppointment = modifiedAppointment;

        //find the one the ID matches
        //   customertxt.setValue(customer);
        for (Customer c : customerCombo) {
            if (c.getCustomerId() == modAppointment.getCustomerId()) {
                customertxt.getSelectionModel().select(c);
                break;
            }
        }

        datetxt.setValue(modifiedAppointment.getStart().toLocalDate());

        typetxt.setValue(modifiedAppointment.getType());

        LocalTime start = modifiedAppointment.getStart().toLocalTime();

        startHour.setValue(start.getHour());

        startMinute.setValue(start.getMinute());

        LocalTime end = modifiedAppointment.getEnd().toLocalTime();

        endHour.setValue(end.getHour());

        endMinute.setValue(end.getMinute());
    }

    /**
     * Initializes the controller class.
     */
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
        starthours.addAll(8, 9, 10, 11, 12, 13, 14, 15, 16, 17);
        startminutes.addAll(0, 15, 30, 45);

        endhours.addAll(8, 9, 10, 11, 12, 13, 14, 15, 16, 17);
        endminutes.addAll(0, 15, 30, 45);

        typeOfApt.addAll("Presentation", "Introduction", "Follow-up");
        startHour.setItems(starthours);
        startMinute.setItems(startminutes);
        typetxt.setItems(typeOfApt);
        endHour.setItems(endhours);
        endMinute.setItems(endminutes);

        try {
            customerCombo = CustomerDAO.getAllCustomers();

        } catch (Exception ex) {
            Logger.getLogger(AddNewCustomerController.class
                    .getName()).log(Level.SEVERE, null, ex);
        }
        customertxt.setItems(customerCombo);
        customertxt.getSelectionModel();

    }

}
