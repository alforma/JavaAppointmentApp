/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import DAO.AddressDAO;
import DAO.CityDAO;
import DAO.CountryDAO;
import DAO.CustomerDAO;
import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import model.Address;
import model.City;
import model.Country;
import model.Customer;
import model.Report;

/**
 * FXML Controller class
 *
 * @author amf74
 */
public class AddNewCustomerController implements Initializable {

    Stage stage;
    Parent scene;

    @FXML
    private TextField customerNametxt;

    @FXML
    private TextField addresstxt;

    @FXML
    private ComboBox<City> citytxt;

    @FXML
    private TextField zipcodetxt;

    @FXML
    private TextField phoneNumbertxt;

    //OBSERVABLE LISTS
    private ObservableList<City> cityCombo;

    @FXML
    void onActionCancel(ActionEvent event) throws IOException {
        Alert cancelAlert = new Alert(Alert.AlertType.CONFIRMATION);
        cancelAlert.setTitle("Cancel Confirmation");
        cancelAlert.setHeaderText("Are you sure you would like to cancel?");
        cancelAlert.setContentText("All data will be lost!");
        cancelAlert.showAndWait();

        //goes back to MainScreen
        stage = (Stage) ((Button) event.getSource()).getScene().getWindow();
        scene = FXMLLoader.load(getClass().getResource("/view/MainCustomerSummary.fxml"));
        stage.setScene(new Scene((Parent) scene));
        stage.show();
    }

    @FXML
    void onActionSave(ActionEvent event) throws IOException, NumberFormatException, SQLException, ClassNotFoundException {

        if (validateCustomer()) {
            try {
                String customerName = customerNametxt.getText();
                String address = addresstxt.getText();
                City city = citytxt.getSelectionModel().getSelectedItem();
                String postalCode = zipcodetxt.getText();
                String phone = phoneNumbertxt.getText();

                Address saveAddress = new Address(0, address, city.getCityId(), postalCode, phone);
                AddressDAO.addAddress(saveAddress);

                Customer saveCustomer = new Customer(customerName, saveAddress.getAddressId());
                CustomerDAO.addCustomer(saveCustomer);

                stage = (Stage) ((Button) event.getSource()).getScene().getWindow();
                scene = FXMLLoader.load(getClass().getResource("/view/MainCustomerSummary.fxml"));
                stage.setScene(new Scene(scene));
                stage.show();
            } catch (NumberFormatException e) {
                System.out.println("Please enter valid values in text fields");
            }
        }
    }

    private boolean validateCustomer() {
        String customerName = customerNametxt.getText();
        String address = addresstxt.getText();
        City city = citytxt.getValue();
        String postalCode = zipcodetxt.getText();
        String phone = phoneNumbertxt.getText();
        String errorMessage = "";

        //first checks to see if inputs are null
        if (customerName == null || customerName.length() == 0) {
            errorMessage += "Please enter the Customer's name.\n";
        }
        if (address == null || address.length() == 0) {
            errorMessage += "Please enter an address.\n";
        }
        if (city == null) {
            errorMessage += "Please Select a City.\n";
        }

        if (postalCode == null || postalCode.length() == 0) {
            errorMessage += "Please enter the Postal Code.\n";

        } else if (postalCode.length() > 10 || postalCode.length() < 5) {
            errorMessage += "Please enter a 5 digit Postal Code.\n";
        }

        if (phone == null || phone.length() == 0) {
            errorMessage += "Please enter a Phone Number";
        } else if (phone.length() <8 || phone.length() > 8) {
            errorMessage += "Please enter a valid phone number inthe form of XXX-XXXX\n";
        }
        if (errorMessage.length() == 0) {
            return true;
        } else {
            // Show the error message.
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.initOwner(stage);
            alert.setTitle("Invalid Fields");
            alert.setHeaderText("Please correct invalid Customer fields");
            alert.setContentText(errorMessage);

            alert.showAndWait();

            return false;
        }
    }

    /**
     * Initializes the controller class.
     *
     * @param url
     * @param rb
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {

        try {
            cityCombo = CityDAO.getAllCities();
        } catch (Exception ex) {
            Logger.getLogger(AddNewCustomerController.class.getName()).log(Level.SEVERE, null, ex);
        }
        citytxt.setItems(cityCombo);

    }

}
