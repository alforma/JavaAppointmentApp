/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import DAO.CustomerDAO;
import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.stage.Stage;
import javafx.fxml.FXML;
import javafx.scene.Node;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import model.Address;
import model.Appointment;
import model.City;
import model.Country;
import model.Customer;

/**
 * FXML Controller class
 *
 * @author amf74
 */
public class MainCustomerSummaryController implements Initializable {

    private Stage stage;
    private Object scene;
    private Customer addedCustomer;
    private Customer modifiedCustomer;
    Appointment selectedappointment;

    @FXML
    private TableView<Customer> customerSummaryTable;

    @FXML
    private TableColumn<Customer, Integer> customerId;

    @FXML
    private TableColumn<Customer, String> customerName;

    @FXML
    private TableColumn<Address, String> address;

    @FXML
    private TableColumn<City, String> city;

    @FXML
    private TableColumn<Address, String> zipCode;

    @FXML
    private TableColumn<Country, String> country;

    @FXML
    private TableColumn<Address, String> phoneNumber;

    ObservableList<Customer> Customers = FXCollections.observableArrayList();

    ObservableList<Customer> customerSummary = FXCollections.observableArrayList();

    ObservableList<Address> Addresses = FXCollections.observableArrayList();
    private Object calendarSummaryTable;
    private Customer custToDelete;

    @FXML
    void onActionAddCustomer(ActionEvent event) throws IOException {

        FXMLLoader loader = new FXMLLoader();
        loader.setLocation(getClass().getResource("/view/AddNewCustomer.fxml"));

        Parent addPartParent = loader.load();
        Scene addPartScene = new Scene(addPartParent);

        AddNewCustomerController controller = loader.getController();

        Stage stage;
        stage = (Stage) ((Node) event.getTarget()).getScene().getWindow();
        stage.setScene(addPartScene);
        stage.show();
    }

    @FXML
    void onActionDeleteCustomer(ActionEvent event) throws ClassNotFoundException, SQLException {
   
        Customer customer = customerSummaryTable.getSelectionModel().getSelectedItem();
 
 customerSummaryTable.getItems().remove(customerSummaryTable.getSelectionModel().getSelectedItem());
             CustomerDAO.deleteCustomer(customer);
            
        }
    
    

    @FXML
    void onActionModifyCustomer(ActionEvent event) throws IOException {

        FXMLLoader loader = new FXMLLoader();
        loader.setLocation(getClass().getResource("/view/ModifyCustomerInformation.fxml"));
        Parent modPartViewParent = loader.load();
        Scene modPartViewScene = new Scene(modPartViewParent);

        // Pass the selected part to the Modify  View
        Customer modifiedCustomer = customerSummaryTable.getSelectionModel().getSelectedItem();

        ModifyCustomerInformation controller = loader.getController();

        controller.setModCustomer(modifiedCustomer);
        // Get Stage information
        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();

        window.setScene(modPartViewScene);
        window.show();

    }

    @FXML
    void onActionBackToLogIn(ActionEvent event) throws IOException {
        stage = (Stage) ((Button) event.getSource()).getScene().getWindow();
        scene = FXMLLoader.load(getClass().getResource("/view/LogInForm.fxml"));
        stage.setScene(new Scene((Parent) scene));
        stage.show();
    }

    @FXML
    void onActionReportSummary(ActionEvent event) throws IOException {

        stage = (Stage) ((Button) event.getSource()).getScene().getWindow();
        scene = FXMLLoader.load(getClass().getResource("/view/RequiredReports.fxml"));
        stage.setScene(new Scene((Parent) scene));
        stage.show();

    }

    @FXML
    void onActionAptSummary(ActionEvent event) throws IOException {
        stage = (Stage) ((Button) event.getSource()).getScene().getWindow();

        scene = FXMLLoader.load(getClass().getResource("/view/Calendar.fxml"));
        stage.setScene(new Scene((Parent) scene));
        stage.show();

    }

//
    /**
     * Initializes the controller class.
     */
    public void initialize(URL url, ResourceBundle rb) {

        customerName.setCellValueFactory(new PropertyValueFactory<>("customerName"));
        address.setCellValueFactory(new PropertyValueFactory<>("address"));

        city.setCellValueFactory(new PropertyValueFactory<>("city"));
        zipCode.setCellValueFactory(new PropertyValueFactory<>("postalCode"));
        country.setCellValueFactory(new PropertyValueFactory<>("country"));
        phoneNumber.setCellValueFactory(new PropertyValueFactory<>("phone"));

        try {
            Customers.addAll(CustomerDAO.getAllCustomers());
            // Addresses.addAll(AddressDAO.getAllAddresses());
        } catch (Exception ex) {
            Logger.getLogger(MainCustomerSummaryController.class.getName()).log(Level.SEVERE, null, ex);
        }
        customerSummaryTable.setItems(Customers);

    }

}
