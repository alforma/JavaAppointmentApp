/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

/**
 *
 * @author amf74
 */
public class Country {

    private int countryid;
    private String country;
    private String createDate;
    private String createdBy;
    private String lastUpdate;
    private String lastUpdateBy;
    private String england;
    private String norway;
    private String us;
    
    public Country() {
        
    }

    public Country(String england, String norway, String us) {
this.england = england;
this.norway = norway;
this.us = us;





    }

    public Country(int countryid, String country, String createDate, String createdBy, String lastUpdate, String lastUpdateBy, String england, String norway, String us) {
        this.countryid = countryid;
        this.country = country;
        this.createDate = createDate;
        this.createdBy = createdBy;
        this.lastUpdate = lastUpdate;
        this.lastUpdateBy = lastUpdateBy;
        this.england = england;
        this.norway = norway;
        this.us = us;
    }

    public Country(String norway) {

    }
    
    

    public String getEngland() {
        return england;
    }

    public void setEngland(String england) {
        this.england = england;
    }

    public String getNorway() {
        return norway;
    }

    public void setNorway(String norway) {
        this.norway = norway;
    }

    public String getUs() {
        return us;
    }

    public void setUs(String us) {
        this.us = us;
    }

    public int getCountryid() {
        return countryid;
    }

    public void setCountryid(int countryid) {
        this.countryid = countryid;
    }
    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }
 
    
    public int getCountryId() {
        return countryid;
    }

    public void setCountryId(int countryid) {
        this.countryid = countryid;
    }

   

    public String getCreateDate() {
        return createDate;
    }

    public void setCreateDate(String createDate) {
        this.createDate = createDate;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public String getLastUpdate() {
        return lastUpdate;
    }

    public void setLastUpdate(String lastUpdate) {
        this.lastUpdate = lastUpdate;
    }

    public String getLastUpdateBy() {
        return lastUpdateBy;
    }

    public void setLastUpdateBy(String lastUpdateBy) {
        this.lastUpdateBy = lastUpdateBy;
    }

    public Country(int countryid, String country, String createDate, String createdBy, String lastUpdate, String lastUpdateBy) {
        this.countryid = countryid;
        this.country = country;
        this.createDate = createDate;
        this.createdBy = createdBy;
        this.lastUpdate = lastUpdate;
        this.lastUpdateBy = lastUpdateBy;
    }

 
      public String toString(String england) {
        return england;
      }
         
}
