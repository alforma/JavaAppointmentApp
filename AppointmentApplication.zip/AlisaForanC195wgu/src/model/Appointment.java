/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.time.LocalDate;
import java.time.LocalDateTime;

/**
 *
 * @author amf74
 */
public class Appointment {

    private int appointmentId;
private String customerName;
    private int customerId;
    private int userId;
 
    private String type;

    private  LocalDateTime start;
    private  LocalDateTime end;


 
 //for the put of the DB
    
    
    public Appointment(int appointmentId, int customerId, String customerName, int userId, String type, LocalDateTime start, LocalDateTime end) {
    this.appointmentId = appointmentId;
        this.customerId = customerId;
       this.customerName = customerName;
    this.userId = userId;
    this.type = type;
    this.start = start;
    this.end = end;
    
    
    }
    
//adding to DB
    
        public Appointment( int customerId, String customerName,  int userId,  String type,  LocalDateTime start, LocalDateTime end) {
 this.appointmentId = 0;
        this.customerId = customerId;
       this.customerName = customerName;
this.userId = userId;
    this.type = type;
    this.start = start;
    this.end = end;
    
    
    }
    
  
    
  

    public String getCustomerName() {
        return customerName;
    }

    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

  

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }


    
    
    

    public int getAppointmentId() {
        return appointmentId;
    }

    public void setAppointmentId(int appointmentId) {
        this.appointmentId = appointmentId;
    }

    public int getCustomerId() {
        return customerId;
    }

    public void setCustomerId(int customerId) {
        this.customerId = customerId;
    }

    public int getUserId() {
        return userId;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }

  

    public LocalDateTime getStart() {
        return start;
    }

    public void setStart(LocalDateTime start) {
        this.start = start;
    }

    public LocalDateTime getEnd() {
        return end;
    }

    public void setEnd(LocalDateTime end) {
        this.end = end;
    }

   

   

}
