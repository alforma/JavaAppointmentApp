/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

/**
 *
 * @author amf74
 */
public class Customer {


        public ObservableList<Appointment> associatedApts = FXCollections.observableArrayList();

    private int customerId;
    private String customerName;
    private int addressId;
    private String address;
    private String city;
    private int cityId;
    private String postalCode;
    private String country;
    private int countryId;
    private String phone;

    public Customer(int customerId, String customerName, int addressId, String address, String city,int cityId,  String country,int countryId, String postalCode, String phone) {
        this.customerId = customerId;
        this.customerName = customerName;
        this.addressId = addressId;
        this.address = address;
        this.city = city;
        this.cityId = cityId;
        this.country = country;
        this.countryId  = countryId;
        this.postalCode = postalCode;
        this.phone = phone;

    }

    public Customer() {

    }

    //this is for inserting into the DB
  public Customer(String customerName, int addressId){
  this.customerName = customerName;
  this.addressId = addressId;
  }

   public Customer(String customerName){
  this.customerName = customerName;

  }
   
   public Customer(int customerId,String customerName){
   this.customerName = customerName;
   this.customerId = customerId;
   
   
   }
  
 

    // Setter and Getters
    public int getAddressId() {
        return addressId;
    }

    public void setAddressId(int addressId) {
        this.addressId = addressId;
    }

    public int getCityId() {
        return cityId;
    }

    public void setCityId(int cityId) {
        this.cityId = cityId;
    }

    public String getCountry() {
        return country;
    }

    public void setCountryId(int countryId) {
        this.countryId = countryId;
    }

    public int getCountryId() {
        return countryId;
    }

    
    
    
    public void setCountry(String country) {
        this.country = country;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getPostalCode() {
        return postalCode;
    }

    public void setPostalCode(String postalCode) {
        this.postalCode = postalCode;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    // Setter and Getters
    public int getCustomerId() {
        return customerId;
    }

    public void setCustomerId(int customerId) {
        this.customerId = customerId;
    }

    public String getCustomerName() {
        return customerName;
    }

    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }
    
    
    
    
    
    
    
    
    
    
    

    //
    public ObservableList<Appointment> getAllAssociatedApts() {
        return associatedApts;

    }

    public void deleteAssociatedAppointment(Appointment associatedApt) {

        associatedApts.remove(associatedApts);
    }

    public void addAssociatedAppointment(Appointment associatedApt) {
        associatedApts.add(associatedApt);
    }

    public ObservableList<Appointment> getAssociatedApts() {
        return associatedApts;
    }

    public void setAssociatedApts(ObservableList<Appointment> associatedApts) {
        this.associatedApts = associatedApts;
    }

    
    
    
    
    
    
    @Override

public String toString(){
return customerName;
}
}


