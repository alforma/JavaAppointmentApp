
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

/**
 *
 * @author amf74
 */
public class Report {

    public static ObservableList<Appointment> allAppointment = FXCollections.observableArrayList();
    public static ObservableList<Customer> allCustomer = FXCollections.observableArrayList();
    public static ObservableList<Address> allAddress = FXCollections.observableArrayList();
    public static ObservableList<City> allCity = FXCollections.observableArrayList();
    public static ObservableList<Country> allCountry = FXCollections.observableArrayList();
    public static ObservableList<Report> allReport = FXCollections.observableArrayList();
    public static ObservableList<User> allUser = FXCollections.observableArrayList();

    //add methods
    public static void addAppointment(Appointment newAppointment) {
        allAppointment.add(newAppointment);
    }

    public static void addCustomer(Customer newCustomer) {
        allCustomer.add(newCustomer);
    }

// update methods
    public static void updateAppointment(int index, Appointment selectedAppointment) {
        allAppointment.set(index, selectedAppointment);
    }

    public static void updateCustomer(int index, Customer selectedCustomer) {
        allCustomer.set(index, selectedCustomer);
    }

    //delete methods
    public static void deleteAppointment(Appointment selectedAppointment) {

        allAppointment.remove(selectedAppointment);
    }

    public static void deleteCustomer(Customer selectedCustomer) {

        allCustomer.remove(selectedCustomer);
    }

    //ObservableLists
    public static ObservableList<Appointment> getAllAppointment() {
        return allAppointment;

    }

    public static ObservableList<Customer> getAllCustomer() {
        return allCustomer;

    }

    public static ObservableList<Address> getAllAddress() {
        return allAddress;

    }
    
      public static ObservableList<City> getAllCity() {
        return allCity;

    }
      
        public static ObservableList<Country> getAllCountry() {
        return allCountry;

    }

          public static ObservableList<Report> getAllReport() {
        return allReport;

    }
          
            public static ObservableList<Address> getAllUser() {
        return allAddress;

    }
    
    
    //Report 
    public Report() {
    }

}
