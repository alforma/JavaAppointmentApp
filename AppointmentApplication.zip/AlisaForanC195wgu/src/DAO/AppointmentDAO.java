
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZoneOffset;
import java.time.ZonedDateTime;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import model.Appointment;
import utilities.DataBaseConnection;
import static utilities.DataBaseConnection.conn;

/**
 *
 * @author amf74
 */
public class AppointmentDAO {

    public static ObservableList<Appointment> getAppointments() throws ClassNotFoundException, SQLException {
        ObservableList<Appointment> allApts = FXCollections.observableArrayList();

        try {

            String query = "SELECT "
                    + "appointment.appointmentId,"
                    + "customer.customerId,"
                    + " customer.customerName, "
                    + "appointment.userId,"
                    + "appointment.start, "
                    + "appointment.end, "
                    + "appointment.type "
                    + "FROM customer, appointment "
                    + "WHERE customer.customerId = appointment.customerId";

            //System.out.println(query);
            PreparedStatement stmt = conn.prepareStatement(query);
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {

                int aptId = rs.getInt("appointmentId");
                int customerId = rs.getInt("customerId");
                String customerName = rs.getString("customerName");
                int userId = rs.getInt("userId");
                String type = rs.getString("type");
                Timestamp startTS = rs.getTimestamp("start");
                Timestamp endTS = rs.getTimestamp("end");

                LocalDateTime start = fromUTC(startTS.toLocalDateTime());
                LocalDateTime end = fromUTC(endTS.toLocalDateTime());

                              
                
                Appointment appointment = new Appointment(aptId, customerId, customerName, userId, type, start, end);

                allApts.add(appointment);
            }

            stmt.close();

        } catch (SQLException ex) {
            throw ex;
        }

        return allApts;

    }

    public static void addTheApt(Appointment addNewApt) {

        String addquery = "INSERT INTO appointment VALUES (NULL,?, ?,  '', '' ,  '', '' , ? , '',?,? ,NOW(),'AMF',NOW(), 'AMF')";
        String sql = "SELECT LAST_INSERT_ID()";

        try {
            PreparedStatement stmt = conn.prepareStatement(addquery);

            // stmt.setInt(1, addNewApt.getAppointmentId());
            stmt.setInt(1, addNewApt.getCustomerId());
            stmt.setInt(2, addNewApt.getUserId());
            stmt.setString(3, addNewApt.getType());
            Timestamp startTS = Timestamp.valueOf(toUTC(addNewApt.getStart()));
            Timestamp endTS = Timestamp.valueOf(toUTC(addNewApt.getEnd()));
            stmt.setTimestamp(4, startTS);

            stmt.setTimestamp(5, endTS);

            stmt.execute();

            //////////////////////////////////////////////////////
            PreparedStatement stmt2 = conn.prepareStatement(sql);

            ResultSet rs2 = stmt2.executeQuery();

            rs2.next();
            int ID = rs2.getInt(1);
            addNewApt.setAppointmentId(ID);
            ///////////////////////////////////////////////////////////////

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    
    
    
    
    public static LocalDateTime fromUTC (LocalDateTime ldt){
    ZonedDateTime zUTC = ldt.atZone(ZoneId.of("UTC"));
    
        ZonedDateTime Zsd = zUTC.withZoneSameInstant(ZoneId.systemDefault());
   
        LocalDateTime cldt = Zsd.toLocalDateTime();
       return cldt;
    
    }
    
    
    
    public static LocalDateTime toUTC (LocalDateTime ldt){
    ZonedDateTime Zsd = ldt.atZone(ZoneId.systemDefault());
    
    ZonedDateTime zUTC = Zsd.withZoneSameInstant(ZoneId.of("UTC"));
    LocalDateTime cldt = zUTC.toLocalDateTime();
    return cldt;
    
    }
    
    
    
    

    public static void updateAPT(Appointment appt) throws SQLException {

        String updatequery = "UPDATE appointment SET appointment.start =?, "
                + "appointment.end =?,"
                + "appointment.type =?,"
                + "appointment.customerId = ? "
                + "WHERE appointmentId = ?";
        try {
            //System.out.println(query);
            PreparedStatement stmt = conn.prepareStatement(updatequery);

            Timestamp startTS = Timestamp.valueOf(toUTC(appt.getStart()));
            Timestamp endTS = Timestamp.valueOf(toUTC(appt.getEnd()));

            stmt.setTimestamp(1, startTS);
            stmt.setTimestamp(2, endTS);
            stmt.setString(3, appt.getType());
            stmt.setInt(4, appt.getCustomerId());
            stmt.setInt(5, appt.getAppointmentId());

            stmt.executeUpdate();

            
         
            
        } catch (SQLException e) {
            e.printStackTrace();
        }

    }

      public static void deleteAppointment(Appointment appointment)  throws ClassNotFoundException, SQLException{
  
          String removeAppointmentQuery = "DELETE FROM appointment WHERE appointmentId = ?";
    
        try {
            PreparedStatement stmt = conn.prepareStatement(removeAppointmentQuery);
            stmt.setInt(1, appointment.getAppointmentId());
            stmt.executeUpdate();
        } catch(SQLException ex) {
            System.out.println(ex.getMessage());
        }
    }
    
     



   
}
