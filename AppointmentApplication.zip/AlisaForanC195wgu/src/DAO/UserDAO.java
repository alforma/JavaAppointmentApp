/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import model.User;
import utilities.DataBaseConnection;

/**
 *
 * @author amf74
 */
public class UserDAO {

    private final static Connection conn = DataBaseConnection.conn;

    public UserDAO() {
    }

    public static ObservableList<User> getUsers() {
        ObservableList<User> users = FXCollections.observableArrayList();

        String getActiveUsers = "SELECT * FROM user ";

        try {
            PreparedStatement stmt = conn.prepareStatement(getActiveUsers);
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                User user = new User();
                user.setUserId(rs.getInt("userId"));
                user.setUsername(rs.getString("username"));
                user.setPassword(rs.getString("password"));
                user.setActive(rs.getString("active"));
                user.setCreatedBy(rs.getString("createdBy"));

                users.add(user);
            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
        return users;
    }

    public static User getUserById(int userId) {
        String getUserByIdSQL = "SELECT * FROM user WHERE userId=?";
        User user = new User();

        try {
            PreparedStatement stmt = conn.prepareStatement(getUserByIdSQL);
            stmt.setInt(1, userId);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                user.setUserId(rs.getInt("userId"));
                user.setUsername(rs.getString("userName"));
                          user.setPassword(rs.getString("password"));
                user.setActive(rs.getString("active"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return user;
    }

    public static User getValidUser(String username, String password) {

        String SQL = "SELECT userId, username, password FROM user WHERE userName=? AND password=?";
        User user = null;

        try {
            PreparedStatement stmt = conn.prepareStatement(SQL);
            stmt.setString(1, username);
            stmt.setString(2, password);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                user = new User();
                user.setUserId(rs.getInt("userId"));
                user.setUsername(rs.getString("userName"));
                user.setPassword(password);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return user;

    }
    
    
    

    
    
        
          
            
            
    
    
    
}
