/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import model.Customer;
import static utilities.DataBaseConnection.conn;

/**
 *
 * @author amf74
 */
public class CustomerDAO {
    
    
    
    

    public static ObservableList<Customer> getAllCustomers() throws ClassNotFoundException, SQLException {
        ObservableList<Customer> allCusts = FXCollections.observableArrayList();
        String getDBCustomer = "SELECT customer.customerName,"
                + " customer.customerId,"
                + " address.phone, "
                + "address.address,"
                + " address.postalCode, "
                + "address.addressId, "
                + "city.city"
                + ", city.cityId, "
                + "country.country,"
                + " country.countryId "
                + "FROM customer, "
                + "address,"
                + " city,"
                + " country "
                + "WHERE customer.addressId = address.addressId "
                + "AND address.cityId = city.cityId AND city.countryId = country.countryId";
        try {
            PreparedStatement stmt = conn.prepareStatement(getDBCustomer);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                Customer customer = new Customer();
                customer.setCustomerName(rs.getString("customer.customerName"));
                customer.setPhone(rs.getString("address.phone"));
                customer.setCustomerId(rs.getInt("customer.customerId"));
                customer.setAddress(rs.getString("address.address"));
                customer.setAddressId(rs.getInt("address.addressId"));
                customer.setCity(rs.getString("city.city"));
                customer.setPostalCode(rs.getString("address.postalCode"));
                customer.setCityId(rs.getInt("city.cityId"));
                customer.setCountryId(rs.getInt("country.countryId"));
                customer.setCountry(rs.getString("country.country"));
                allCusts.add(customer);

            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return allCusts;

    }

    public static Customer addCustomer(Customer customer) {
        String addCustomerSQL = "INSERT INTO customer VALUES (NULL, ?, ?,1,NOW(),'AMF',NOW(), 'AMF')";

        try {

            PreparedStatement stmt = conn.prepareStatement(addCustomerSQL);
            // stmt.setInt(1, customer.getCustomerId());
            stmt.setString(1, customer.getCustomerName());
            stmt.setInt(2, customer.getAddressId());

            stmt.execute();
        } catch (SQLException ex) {
        }
        return customer;
    }



    public static void updateCustomer(Customer customer) {
        String updateCustomerDataBase = "UPDATE customer SET customerName=? WHERE customerId =?";

        try {
            PreparedStatement stmt = conn.prepareStatement(updateCustomerDataBase);

            stmt.setString(1, customer.getCustomerName());
            stmt.setInt(2, customer.getCustomerId());

            stmt.executeUpdate();

//         stmt.execute();
        } catch (SQLException e) {
            e.printStackTrace();
        }

    }


    public static void deleteCustomer(Customer customerToDelete)   {
          ObservableList<Customer> allCusts = FXCollections.observableArrayList();
               String removeCustomer = "DELETE FROM customer WHERE customerId = ?";
               
    
        try {
            PreparedStatement stmt = conn.prepareStatement(removeCustomer);
            stmt.setInt(1, customerToDelete.getCustomerId());
               if(stmt.getUpdateCount() > 0)
             CustomerDAO.deleteCustomer(customerToDelete);
                allCusts.remove(customerToDelete);
              stmt.executeUpdate();   
        } catch(SQLException ex) {
            System.out.println(ex.getMessage());
        }
       
    }

    // Saves new Customer to Database
    public static void saveCustomer(Customer saveTheCustomer) {

        String saveAddedCustomer = "SELECT customer.customerName,"
                + " customer.customerId,"
                + " address.phone "
                + "address.address "
                + "address.postalCode, "
                + "address.addressId, "
                + "city.city, "
                + "city.cityId, "
                + "country.country,"
                + " country.countryId "
                + "FROM customer, "
                + "address, city, country "
                + "WHERE customer.addressId = address.addressId "
                + "AND address.cityId = city.cityId"
                + " AND city.countryId = country.countryId";
        try {

            PreparedStatement stmt = conn.prepareStatement(saveAddedCustomer);

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

}
