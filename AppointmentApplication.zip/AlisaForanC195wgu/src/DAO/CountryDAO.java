/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import model.City;
import model.Country;
import utilities.DataBaseConnection;
import static utilities.DataBaseConnection.conn;
import utilities.Query;

/**
 *
 * @author amf74
 */
public class CountryDAO {

    public static ObservableList<Country> getAllCountries() throws ClassNotFoundException, SQLException {
        ObservableList<Country> allCountries = FXCollections.observableArrayList();
        String sqlStatement = "SELECT country, countryId, createDate, createdBy, lastUpdate, lastUpdateBy FROM country";

        
        
          try {
        PreparedStatement stmt = conn.prepareStatement(sqlStatement);
        ResultSet rs = stmt.executeQuery();
        while (rs.next()) {
           Country country = new Country();
       
           country.setCountry(rs.getString("country.country"));
          country.setCountryId(rs.getInt("country.countryId"));
          country.setCreateDate(rs.getString("country.createDate"));
          country.setCreatedBy(rs.getString("country.createdBy"));
            country.setLastUpdate(rs.getString("country.lastUpdate"));
           country.setLastUpdateBy(rs.getString("country.lastUpdateBy"));
          allCountries.add(country);

        }
} catch (SQLException e) {
            e.printStackTrace();
        }
        return    allCountries;

    }

    public static Country addCountry( Country country) {
        String countrySQL = "INSERT INTO country (country,countryId, createDate, createdBy, lastUpdate, lastUpdateBy)"
                + "VALUES (?,?, ?, NOW(), ?, NOW(), ?)";

        try {
            PreparedStatement stmt = conn.prepareStatement(countrySQL);

       
            stmt.setString(2, country.getCountry());
            stmt.setInt(3, country.getCountryId());
            stmt.setString(4,country.getCreateDate());
            stmt.setString(5, country.getCreatedBy());
            stmt.setString(6, country.getLastUpdate());
            stmt.setString(7, country.getLastUpdateBy());

            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return country;
    }

    public static City updatecountry(City updatecountry) throws SQLException {
        String updateCountrysql = "UPDATE city, country"
                + "SET country= ?"
            
                + "countryId = ?"
                + "createDate =?"
                + "createdBy=?"
                + " lastUpdate=?"
                + "lastUpdateBy=?"
                + "WHERE city.countryId = city.countryId";
                
        try {
            PreparedStatement stmt = conn.prepareStatement(updateCountrysql);
                  stmt.setInt(1, updatecountry.getCityId());
            stmt.setString(2, updatecountry.getCity());
            stmt.setInt(3, updatecountry.getCountryId());
            stmt.setString(4, updatecountry.getCreateDate());
            stmt.setString(5, updatecountry.getCreatedBy());
            stmt.setString(6,updatecountry.getLastUpdate());
            stmt.setString(7, updatecountry.getLastUpdateBy());

            stmt.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return updatecountry;

    }

}
