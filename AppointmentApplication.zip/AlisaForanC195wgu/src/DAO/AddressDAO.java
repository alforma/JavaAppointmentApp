

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import model.Address;
import static model.Report.allAddress;
import static utilities.DataBaseConnection.conn;

/**
 *
 * @author amf74
 */
public class AddressDAO {

    //GET ALL ADDRESSES
    public static ObservableList<Address> getAllAddresses() {
        ObservableList<Address> allAddresses = FXCollections.observableArrayList();
        String addressDB = "SELECT * FROM address";

        try {
            PreparedStatement stmt = conn.prepareStatement(addressDB);
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                Address adr = new Address();

                adr.setAddressId(rs.getInt("addressId"));
                adr.setAddress(rs.getString("address"));
                adr.setCityId(rs.getInt("cityId"));
                // adr.setCountryId(rs.getInt("countryId"));
                adr.setPostCode(rs.getString("postalCode"));
                adr.setPhone(rs.getString("phone"));

                allAddresses.add(adr);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return allAddresses;
    }

    //ADD ADDRESS FOR CUSTOMER
    public static Address addAddress(Address address) {
        String addressDB = "INSERT INTO address VALUES (NULL, ?, '',?, ?, ?,NOW(),'AMF',NOW(), 'AMF')";
        String sql = "SELECT LAST_INSERT_ID()";
        try {
            PreparedStatement stmt = conn.prepareStatement(addressDB);

            stmt.setString(1, address.getAddress());

            stmt.setInt(2, address.getCityId());

            stmt.setString(3, address.getPostCode());
            stmt.setString(4, address.getPhone());

            stmt.execute();

            //////////////////////////////////////////////////////
            PreparedStatement stmt2 = conn.prepareStatement(sql);

            ResultSet rs2 = stmt2.executeQuery();

            rs2.next();
            int ID = rs2.getInt(1);
            address.setAddressId(ID);
            ///////////////////////////////////////////////////////////////
        
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return address;
    }

//UPDATE ADDRESS FOR CUSTOMER
    public static void updateAddress(Address adr) {
        String updateAddressDB = "UPDATE address"
                + " SET address = ? ,"
                + "cityId = ? ,"
                + " phone = ? ,"
                + "  postalCode = ? "
                + "WHERE addressId = ?";

        try {
            PreparedStatement stmt = conn.prepareStatement(updateAddressDB);

            stmt.setString(1, adr.getAddress());
            stmt.setInt(2, adr.getCityId());
            stmt.setString(3, adr.getPhone());
            stmt.setString(4, adr.getPostalCode());
      stmt.setInt(5, adr.getAddressId());

            stmt.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    //DELETE CUSTOMER USING THEIR ID
    public static void deleteAddress(Address adr) {
        String deleteAddressDB = "DELETE FROM address WHERE addressId = ?";

        try {
            PreparedStatement stmt = conn.prepareStatement(deleteAddressDB);
            stmt.setInt(1, adr.getAddressId());
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static ObservableList<Address> getAllAddress() {
        return allAddress;

    }

}
