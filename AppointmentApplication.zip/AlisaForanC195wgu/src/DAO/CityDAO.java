/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Calendar;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import model.City;
import model.User;
import utilities.DataBaseConnection;
import static utilities.DataBaseConnection.conn;
import utilities.Query;

/**
 *
 * @author amf74
 */
public class CityDAO {

    public static ObservableList<City> getAllCities() throws ClassNotFoundException, SQLException {
        ObservableList<City> allCities = FXCollections.observableArrayList();
        String sqlStatement = "SELECT cityId, city, countryId, createDate, createdBy, lastUpdate, lastUpdateBy FROM city";

        
        
          try {
        PreparedStatement stmt = conn.prepareStatement(sqlStatement);
        ResultSet rs = stmt.executeQuery();
        while (rs.next()) {
            City city = new City();
            city.setCityId(rs.getInt("city.cityId"));
            city.setCity(rs.getString("city.city"));
            city.setCountryId(rs.getInt("city.countryId"));
            city.setCreateDate(rs.getString("city.createDate"));
            city.setCreatedBy(rs.getString("city.createdBy"));
            city.setLastUpdate(rs.getString("city.lastUpdate"));
            city.setLastUpdateBy(rs.getString("city.lastUpdateBy"));
            allCities.add(city);

        }
} catch (SQLException e) {
            e.printStackTrace();
        }
        return allCities;

    }

    public static City addCity(City addCity) {
        String addCitySQL = "INSERT INTO city (cityId, city,countryId, createDate, createdBy, lastUpdate, lastUpdateBy)"
                + "VALUES (?,?, ?, NOW(), ?, NOW(), ?)";

        try {
            PreparedStatement stmt = conn.prepareStatement(addCitySQL);

            stmt.setInt(1, addCity.getCityId());
            stmt.setString(2, addCity.getCity());
            stmt.setInt(3, addCity.getCountryId());
            stmt.setString(4, addCity.getCreateDate());
            stmt.setString(5, addCity.getCreatedBy());
            stmt.setString(6, addCity.getLastUpdate());
            stmt.setString(7, addCity.getLastUpdateBy());

            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return addCity;
    }

    public static City updatecity(City updateCity) throws SQLException {
        String updateCitysql = "UPDATE city"
                + "SET cityId= ?"
                + "city = ?"
                + "countryId = ?"
                + "createDate =?"
                + "createdBy=?"
                + " lastUpdate=?"
                + "lastUpdateBy=?"
                + "WHERE city.countryId = city.countryId";
                
        try {
            PreparedStatement stmt = conn.prepareStatement(updateCitysql);
                  stmt.setInt(1, updateCity.getCityId());
            stmt.setString(2, updateCity.getCity());
            stmt.setInt(3, updateCity.getCountryId());
            stmt.setString(4, updateCity.getCreateDate());
            stmt.setString(5, updateCity.getCreatedBy());
            stmt.setString(6, updateCity.getLastUpdate());
            stmt.setString(7, updateCity.getLastUpdateBy());

            stmt.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return updateCity;

    }

}
