NOTES FOR EVALUATOR:

overlap is in add/modify appointment controllers

15 min alert is in logIncontroller

method for writing text to a file is in logincontroller

username and password is 'test' and 'test'

other language is Spanish

SQL information is in DAO

LAMBDA EXPRESSIONS ARE IN CALENDAR CONTROLLER

THE MONTH AND WEEK VIEW ARE located on the Appointment Summary Page---(APPOINTMENT SUMMARY BUTTON IS LOCATED ON THE MAIN PAGE AFTER ONE LOGS IN)
	--"VIEW APPOINTMENTS BY next 7 days (week)"
        --"VIEW APPOINTMENT BY next 30 days month"